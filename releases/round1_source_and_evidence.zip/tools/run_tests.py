"""Portable Verilator regression. Native fallback is explicitly non-compliant.

Standard: python3 tools/run_tests.py (Verilator 5.050 + C++ toolchain on PATH).
Windows fallback: --native-root PATH --zig PATH --allow-version-mismatch.
No tool installation, global environment changes or production source mutation.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from generate_vectors import generate
from test_replay import test as test_replay

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build"
START = time.monotonic()


def run(cmd, log, env=None, timeout=180, expected_failure=False):
    remaining = 295 - (time.monotonic() - START)
    if remaining <= 0:
        raise RuntimeError("regression exceeded 295 second budget")
    p = subprocess.run([str(x) for x in cmd], cwd=ROOT, env=env, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       errors="replace", timeout=min(timeout, remaining))
    log.write_text(p.stdout, encoding="utf-8")
    if p.returncode and not expected_failure:
        print(p.stdout[-14000:])
        raise RuntimeError(f"command failed ({p.returncode}): {cmd[0]}; {log}")
    return p


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--native-root", type=Path)
    parser.add_argument("--zig", type=Path)
    parser.add_argument("--allow-version-mismatch", action="store_true")
    parser.add_argument("--skip-mutation", action="store_true", help="development only; not an R6 run")
    a = parser.parse_args()
    BUILD.mkdir(exist_ok=True)
    env = os.environ.copy()
    (BUILD/"tmp").mkdir(exist_ok=True)
    env["TMP"] = env["TEMP"] = str(BUILD/"tmp")
    if a.native_root:
        verilator = a.native_root / "bin/verilator_bin.exe"
        env["VERILATOR_ROOT"] = a.native_root.as_posix()
        if not a.zig:
            raise RuntimeError("native Windows mode requires --zig path to zig.exe")
        env["ZIG_GLOBAL_CACHE_DIR"] = str(BUILD / "zig_global")
        env["ZIG_LOCAL_CACHE_DIR"] = str(BUILD / "zig_local")
    else:
        verilator = shutil.which("verilator")
        if not verilator:
            raise RuntimeError("Verilator 5.050 not on PATH. See README for explicit local fallback.")
    version = run([verilator, "--version"], BUILD / "version.log", env).stdout.strip()
    compliant_version = bool(re.search(r"Verilator\s+5\.050\b", version))
    if not compliant_version and not a.allow_version_mismatch:
        raise RuntimeError(f"Required Verilator 5.050, got {version!r}. Local fallback needs explicit --allow-version-mismatch.")
    print("Simulator:", version, flush=True)
    if not compliant_version:
        print("LOCAL DEVELOPMENT RUN: does not certify R6 Verilator 5.050", flush=True)
    generate(BUILD / "vision_vectors.txt")
    test_replay(BUILD / "replay_selftest")
    sources = sorted((ROOT / "rtl").rglob("*.sv"))
    fixture = [ROOT / "tb/mock_motor_packet.sv", ROOT / "tb/verification_top.sv"]
    original_hash = hashlib.sha256((ROOT / "rtl/motor/motion_control.sv").read_bytes()).hexdigest()

    def compile_test(label, rtl):
        obj = BUILD / label
        obj.mkdir(exist_ok=True)
        command = [verilator, "--cc", "--assert", "--top-module", "verification_top",
                   "--Mdir", obj, "--prefix", "Vverification_top", *rtl, *fixture]
        if not a.native_root:
            command += ["--exe", ROOT/"tb/test_main.cpp", "--build", "-j", "2", "-CFLAGS", "-std=c++17"]
        run(command, BUILD / f"{label}_compile.log", env)
        if a.native_root:
            exe = obj / "robot_tests.exe"
            run([a.zig, "c++", "-std=c++17", "-O1", "-DVL_TIME_CONTEXT",
                 "-I"+str(obj), "-I"+str(a.native_root/"include"), "-I"+str(a.native_root/"include/vltstd"),
                 *sorted(obj.glob("*.cpp")), a.native_root/"include/verilated.cpp",
                 a.native_root/"include/verilated_threads.cpp", ROOT/"tb/test_main.cpp", "-o", exe],
                BUILD/f"{label}_link.log", env)
        else:
            exe = obj / "Vverification_top"
        return exe

    # Full size default core elaborates separately from reduced simulation fixture.
    run([verilator, "--lint-only", "--assert", "--top-module", "robot_core", *sources], BUILD/"full_size_lint.log", env)
    positive = compile_test("positive", sources)
    result = run([positive, BUILD/"vision_vectors.txt"], BUILD/"positive.log", env)
    if "ALL TESTS PASSED" not in result.stdout:
        raise RuntimeError("positive test lacks completion marker")
    print(result.stdout, end="", flush=True)
    caught = False
    if not a.skip_mutation:
        mutation = BUILD / "mutation_motion_control.sv"
        original = (ROOT/"rtl/motor/motion_control.sv").read_text(encoding="utf-8")
        needle = "left=inhibit ? 16'sd0"
        if original.count(needle) != 1:
            raise RuntimeError("mutation location changed; review injection")
        mutation.write_text(original.replace(needle, "left=inhibit ? 16'sd1"), encoding="utf-8")
        mutated_sources = [mutation if p.name == "motion_control.sv" else p for p in sources]
        negative = compile_test("negative", mutated_sources)
        fail = run([negative, BUILD/"vision_vectors.txt"], BUILD/"negative.log", env, expected_failure=True)
        caught = fail.returncode != 0 and "CHECK FAILED: motor inhibit zero" in fail.stdout
        if not caught:
            raise RuntimeError("mutation did not fail on the intended assertion")
        print("CAUGHT deliberately broken motion_control: nonzero inhibited left motor", flush=True)
    if hashlib.sha256((ROOT/"rtl/motor/motion_control.sv").read_bytes()).hexdigest() != original_hash:
        raise RuntimeError("production source changed during mutation")
    elapsed = time.monotonic() - START
    report = dict(status="PASS", seconds=round(elapsed, 3), version=version,
                  verilator_5050=compliant_version, mutation_caught=caught,
                  r6_automated_gate=compliant_version and caught and elapsed < 300,
                  hardware_tested=False, synthetic_golden_frames=36,
                  source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in sources+fixture+[ROOT/"tb/test_main.cpp"]})
    (BUILD/"test_results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"PASS regression completed in {elapsed:.2f}s; R6 exact-version gate={report['r6_automated_gate']}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, subprocess.TimeoutExpired, OSError) as e:
        print(f"FAIL {e}", file=sys.stderr)
        sys.exit(1)
