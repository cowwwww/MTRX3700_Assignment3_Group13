"""Create a core resource-estimation project with virtual pins, never a board image."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
q = ROOT/"quartus"
q.mkdir(exist_ok=True)
lines = ['set_global_assignment -name FAMILY "Cyclone V"',
         'set_global_assignment -name DEVICE 5CSEMA5F31C6',
         'set_global_assignment -name TOP_LEVEL_ENTITY robot_core',
         'set_global_assignment -name PROJECT_OUTPUT_DIRECTORY output_files',
         'set_global_assignment -name NUM_PARALLEL_PROCESSORS 2',
         'set_global_assignment -name SDC_FILE robot_core.sdc',
         '# Virtual data pins, unassigned clock pins: NOT a board design.']
scalar_ports = 'arst pixel_valid sof eof dark_line stop_event release_event bypass sensor_required distance_sample distance_valid inhibited stopped cdc_fault debug_feature_valid debug_frame_good'.split()
vector_ports = 'gray threshold x y distance_mm motor_left motor_right nav_state debug_row_valid debug_junction debug_centroids debug_counts debug_frame_id'.split()
for port in scalar_ports + [name+'[*]' for name in vector_ports]:
    lines.append('set_instance_assignment -name VIRTUAL_PIN ON -to '+port)
for p in sorted((ROOT/'rtl').rglob('*.sv')):
    lines.append('set_global_assignment -name SYSTEMVERILOG_FILE ../'+p.relative_to(ROOT).as_posix())
(q/'robot_core.qsf').write_text('\n'.join(lines)+'\n', encoding='ascii')
(q/'robot_core.qpf').write_text('QUARTUS_VERSION = "18.1"\nPROJECT_REVISION = "robot_core"\n',encoding='ascii')
print('PASS created Quartus virtual-pin resource-estimation project')
