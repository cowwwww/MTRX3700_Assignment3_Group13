// One compiled test fixture; C++ drives independent module and system tests.
module verification_top(
 input logic clk,cam_clk,arst,
 input logic pixel_valid,sof,eof,
 input logic [7:0] gray,threshold,
 input logic dark_line,
 input logic [4:0] x,
 input logic [3:0] y,
 input logic stop_event,release_event,bypass,sensor_required,
 input logic distance_sample,distance_valid,
 input logic [15:0] distance_mm,
 output logic signed [15:0] motor_left,motor_right,
 output logic inhibited,stopped,cdc_fault,mock_tx,
 output logic [3:0] nav_state,
 output logic debug_feature_valid,debug_frame_good,
 output logic [2:0] debug_row_valid,debug_junction,
 output logic [14:0] debug_centroids,
 output logic [17:0] debug_counts,
 output logic [15:0] debug_frame_id,
 input logic unit_reset,unit_inhibit,
 input logic signed [15:0] unit_steering,
 input logic [7:0] unit_speed,
 output logic signed [15:0] unit_left,unit_right,
 input logic [14:0] unit_centroids,
 output logic signed [15:0] unit_basic,unit_advanced,unit_heading,unit_curvature,
 input logic unit_uart_valid,unit_uart_abort,
 input logic [7:0] unit_uart_data,
 output logic unit_uart_tx,unit_uart_ready,unit_uart_busy,
 input logic div_start,
 input logic [17:0] div_n,div_d,
 output logic div_busy,div_done,div_zero,
 output logic [17:0] div_q,
 input logic j_present,j_request,
 input logic [7:0] j_key,
 input logic [2:0] j_available,
 output logic j_valid,j_revisited,
 output logic [1:0] j_choice,
 input logic d_sample,d_valid,
 input logic [15:0] d_mm,
 output logic d_blocked,d_fault,
 output logic unit_stopped
);
 robot_core #(.W(32),.H(16),.FRAME_TIMEOUT(30000),.DISTANCE_TIMEOUT(50000),.RECOVER_FRAMES(3)) core(
  .clk,.cam_clk,.arst,.pixel_valid,.sof,.eof,.gray,.threshold,.dark_line,.x,.y,
  .stop_event,.release_event,.bypass,.sensor_required,.distance_sample,.distance_valid,.distance_mm,
  .motor_left,.motor_right,.inhibited,.stopped,.cdc_fault,.nav_state,.debug_feature_valid,.debug_frame_good,
  .debug_row_valid,.debug_junction,.debug_centroids,.debug_counts,.debug_frame_id);
 mock_motor_packet packet(.clk,.reset(arst),.inhibit(inhibited),.left(motor_left),.right(motor_right),.tx(mock_tx));
 motion_control unit_motor(.inhibit(unit_inhibit),.steering(unit_steering),.speed(unit_speed),.left(unit_left),.right(unit_right));
 curve_fit #(.W(32)) unit_curve(.centroids(unit_centroids),.basic_error(unit_basic),.advanced_error(unit_advanced),.heading(unit_heading),.curvature(unit_curvature));
 uart_tx #(.CLKS_PER_BIT(4)) unit_uart(.clk,.reset(unit_reset),.abort_tx(unit_uart_abort),
  .valid(unit_uart_valid),.data(unit_uart_data),.ready(unit_uart_ready),.tx(unit_uart_tx),.busy(unit_uart_busy));
 unsigned_divider unit_div(.clk,.reset(unit_reset),.start(div_start),.numerator(div_n),.denominator(div_d),
  .busy(div_busy),.done(div_done),.divide_by_zero(div_zero),.quotient(div_q));
 junction_memory #(.DEPTH(4)) unit_junction(.clk,.reset(unit_reset),.present(j_present),.request(j_request),
  .key(j_key),.available(j_available),.decision_valid(j_valid),.revisited(j_revisited),.choice(j_choice));
 distance_guard #(.TIMEOUT_CYCLES(40)) unit_distance(.clk,.reset(unit_reset),.sample(d_sample),.valid(d_valid),
  .distance_mm(d_mm),.blocked(d_blocked),.fault(d_fault));
 safety_stop unit_safety(.clk,.reset(unit_reset),.stop_event,.release_event,.stopped(unit_stopped));
endmodule
