# Integration contracts

See ARCHITECTURE.md for current widths, formulae, states and clock domains.

## robot_core inputs

| Port group | Producer obligation |
|---|---|
| clk, cam_clk, arst | Free-running clocks; assert global reset to both domains before stream/control use |
| pixel_valid / gray / x / y / sof / eof | Camera-clock synchronous, one complete in-order raster per frame; SOF/EOF on the first/last valid pixels, gaps allowed |
| threshold / dark_line | Camera-domain stable at SOF; core snapshots them for each frame |
| stop_event / release_event | Control-clock synchronous pulses from distinct decoded IR keys; stop must not be suppressed by held-key/repeat handling |
| bypass | Control-clock synchronized SW0; 1 = basic, 0 = quadratic lookahead |
| distance_sample / valid / mm | Control-clock atomic measurement event, validity and calibrated mm |
| sensor_required | Board configuration; 1 means missing/invalid/stale readings inhibit; simulation can use 0 while no sensor adapter exists |

There is no pixel ready/backpressure. Camera cannot wait for downstream logic.
Frame cadence must allow divider completion (default 17 camera clocks plus
publication) and mailbox acknowledgement before the next published result.
At default dimensions the raster itself easily exceeds this interval. A mailbox
overrun is latched as a fault instead of silently mixing or losing feature data.

## robot_core outputs

`motor_left/right` are continuously valid signed abstract targets. They are not
UART-encoded, not PWM duty cycles, and not m/s. `inhibited=1` guarantees both
values are zero at the core boundary. The physical UART adapter must prioritize
stop over periodic motion and must not replay old queued targets after release.

`debug_feature_valid` pulses once per transferred frame. All debug feature fields
are held coherently between pulses. The future packet logger/VGA overlay must
sample on that pulse and preserve the frame ID. `debug_junction` only indicates
multiple dark/bright runs or excessive width; it is not a stable junction ID.

## Generic uart_tx

Byte accepted on a rising control clock when valid && ready. Producer must hold
data and valid until acceptance. 8N1, LSB first, `CLKS_PER_BIT` clocks per bit.
Reset/abort discard an in-flight character and drive idle at the next clock.
Default 434 clocks is a configurable development setting, not a verified robot
baud requirement. Receiver resynchronization depends on the real protocol.

## Standalone junction_memory

`present` defines one junction episode; `request` asks for a decision only when
present. `key` must identify the same physical junction across revisits. Bits of
available are left=0, straight=1, right=2. Output choice is the selected bit index.
No choice when available=0; after one decision, present must drop before another.
All keys/history clear on reset. Default depth 8 uses round-robin replacement.
An optional VO/localization pipeline may supply an ID later; no ID fabrication
or junction steering is hidden inside this first version.

## Future obstacle recovery and VO

Obstacle recovery should consume distance validity/age, line features and an
explicit manoeuvre timeout. Its request must go through the same safety arbiter.
With VO invalid it must still have a bounded fallback. Present baseline only
stops and waits for fresh visible line/distance, so new moving states require
new system tests and physical clearances.

VO interface is a design reservation only: `(frame_id, dx, dy, dtheta, valid,
confidence, age)` with units/formats to be selected from real image recordings.
There is deliberately no synthesizable fake VO implementation.
