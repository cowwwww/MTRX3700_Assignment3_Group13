# AI and engineering decision record

Tool: Codex, 19 October 2026. User requested starting the MTRX3700 Major Project
implementation, with output under ASSIGNMENT3/WORK and a system/progress report.
User explicitly identified the existing major-project report as reused A2 content.

This is an initial record, not the final required one-page statement. Preserve
the exported relevant chat separately for final submission. Every source marked
new in OWNERS.md is AI-assisted and requires the responsible student's review.

Decisions made this round:

1. Use streaming row statistics rather than A2's static image-ROM scanner. This
   accepts live valid-pixel timing without a frame buffer and leaves camera
   capture/configuration dependent on official resources.
2. Divide the three sums iteratively in parallel. This bounds division latency
   and avoids three large variable combinational dividers in the main path.
3. Cross feature packets after frame completion, reusing V9's request/ack mailbox.
   Detect producer overflow and require reset instead of silently losing data.
4. Keep all motion decisions and per-pixel work in RTL. The Nano interface remains
   an unimplemented relay adapter until its actual protocol is available.
5. Use conservative stationary recovery. No open-loop blind detour is presented
   as completed obstacle avoidance, and command integration is not called VO.

Errors/limitations found and addressed during verification:

- Quartus 18.1 rejected the implicit generate / inline genvar style and a unary
  negation adjacent to an int cast. Explicit generate/genvar and parentheses
  fixed synthesis portability; default-size elaboration and synthesis were rerun.
- Windows headers define legacy `near`/`far` macros. C++ test argument names were
  changed to near_x/far_x; this was a host build issue, not an FPGA defect.
- Quartus 18.1 does not accept `set_max_delay -datapath_only`. Constraints were
  rewritten with supported max/min delay commands and subsequently rechecked.
- Scope of virtual pins initially matched internal nodes or used QSF quoting
  that Quartus treated literally. Assignments were restricted to actual data
  ports; clock ports remain physical but unassigned because board mapping is absent.
- Review identified a stale distance clear-count hazard at a timeout/sample
  boundary. Fresh sequences now restart at one when faulted; timeout recovery
  is part of the regression. No physical safety result is inferred from it.
- Local Verilator package metadata says 5.48.0 and its binary prints an unknown
  development version. Exact 5.050 compliance remains unverified; scripts reject
  a mismatch by default rather than silently claiming the required version.

Validation uses an independently formulated Python batch model, C++ assertions
including exhaustive small curve cases, wire-level UART checks, disposable
RTL mutation and Quartus core resource/timing analysis. Hardware adapter inputs,
electrical connections, image calibration and mechanical behaviour remain open.
