# Validation and evidence plan

## Automated coverage

The C++ bench drives independent asynchronous clocks (control period 10 ticks,
camera period 14 ticks), samples complete frame features and independently
decodes UART 8N1 output. It runs unit and system functions under one compiled
test fixture to reduce clean-build time. A separate elaboration checks the full
320×240 core. Standard run requires Verilator 5.050; local fallback requires an
explicit opt-in and never labels itself as exact-version compliance.

| Test group | Assertions |
|---|---|
| Safety | Reset stop, persistent latch, 600 event sequences, simultaneous stop/release |
| Motion | Saturation and sign at extreme signed inputs, unconditional inhibited zero |
| Curve fit | All 32³ centroid triples against independent rational interpolation |
| Divider | 220 random/zero denominator cases, exact 18-cycle standalone latency |
| UART | All 256 bytes at exact bit timing, abort at all 40 character-clock positions |
| Distance | Reset invalid, inclusive thresholds, consecutive clear samples, hysteresis interruption, invalid and timeout |
| Junction | New key, revisit, no repeated event per episode, exhausted branches, no choices, eviction |
| Vision | 36 independently modeled synthetic frames, both polarities, equality threshold, narrow/broad/split/random lines, pixel gaps, malformed coordinate |
| System | Camera-derived steering, atomic CDC, SW0 behavioural difference, decoded mock packet, release/freshness, line loss, frozen stream, missing distance, obstacle, priority, CDC overflow |
| Mutation | Change inhibited left wheel zero to one in disposable copy; require the intended assertion failure and CAUGHT |

Digital tests do not simulate optical noise, metastability, chassis inertia,
motor packet compatibility or physical remote range. Full-size lint is not
functional replay at 320×240. Core synthesis is not a board fit.

## Pitch targets retained (not yet finalized)

| Target | Proposed procedure | Conditions / threshold / goal / measured |
|---|---|---|
| T1 Line re-acquisition error (mm) | Three recoveries; greatest lateral offset from desired line | TBD with group after moving recovery exists |
| T2 Recovery time (s) | Three trials from obstacle trigger to stable tracking; maximum elapsed time | TBD; present stationary recovery does not satisfy the planned detour |
| T3 Camera-to-UART latency (ms) | Three scene changes; first changed frame to first actual command bit; maximum | TBD; use SignalTap and actual serial output |
| T4 Visual odometry error (mm) | Three known displacements; maximum absolute estimation error | Deferred with VO; no measurement or fabricated replacement |

If VO does not become viable, select a genuine contribution-based accuracy or
repeatability target before the final datasheet. For example, a measured
curve-following lateral error could be proposed, but its conditions and limits
must come from the group and real testing. Do not copy example brief values.

## Hardware replay acquisition

Record `frame,x,y,gray` for valid camera pixels and a separate RTL feature CSV
with `frame,frame_good,row_valid,junction,far_x,mid_x,near_x,far_count,mid_count,near_count`.
Frame IDs must refer to the same captured frame; unwrap 16-bit rollover for a
long recording. Record dimensions, polarity, threshold, clock rates, FPGA source
hash/bitstream, date, capture method, camera settings and scene alongside data.
Never generate the recorded RTL CSV from the golden model.

The batch replay comparator expects complete frames, one SOF/EOF pair and no
coordinate faults. Malformed-stream behaviour is checked separately by the
cycle-level testbench; the batch model's counts are not intended to mimic
discarded malformed pixels. For hardware R7, record valid complete frames first.

```bash
python3 tools/compare_replay.py --pixels data/hardware/pixels.csv \
  --rtl data/hardware/rtl_features.csv --width 320 --height 240 --threshold 96
```

No hardware data currently exists in this project. Synthetic vectors are generated
under build/ and explicitly identified in test_results.json.
