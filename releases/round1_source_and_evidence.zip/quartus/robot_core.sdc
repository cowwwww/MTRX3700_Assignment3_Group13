# CORE ESTIMATION ONLY: clk=50 MHz, cam_clk=24 MHz is an assumption.
# Replace with official clock/pin/configuration files before board integration.
create_clock -name control -period 20.000 [get_ports {clk}]
create_clock -name camera -period 41.667 [get_ports {cam_clk}]
derive_clock_uncertainty
# Synchronizer first stages only. Do not false-path the entire CDC data bus.
set_false_path -to [get_registers {*features_crossing*req_sync[0]}]
set_false_path -to [get_registers {*features_crossing*ack_sync[0]}]
set_false_path -to [get_registers {*overrun_sync[0]}]
# Bundled payload is held until ack. It must settle before destination capture.
# Explicit max delay bounds the bus to one control period; metastability resolves
# through the separate two-stage req synchronizer before data is sampled.
set_max_delay 20.0 -from [get_registers {*features_crossing*payload*}] -to [get_registers {*features_crossing*dst_data*}]
set_min_delay 0.0 -from [get_registers {*features_crossing*payload*}] -to [get_registers {*features_crossing*dst_data*}]
set_false_path -from [get_ports {arst}]
# External synchronous adapters have not been designed. No physical I/O timing
# signoff is claimed; constrain their real arrivals/loads in the board project.
