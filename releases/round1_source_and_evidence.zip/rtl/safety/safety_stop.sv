// Decoded synchronous key events. Reset is stopped; only release_event arms.
module safety_stop(input logic clk,reset,stop_event,release_event,output logic stopped);
 always_ff @(posedge clk) begin
  if(reset || stop_event) stopped<=1;
  else if(release_event) stopped<=0;
 end
endmodule
