# MTRX3700 Major Project — Group 13 robot core

本项目独立于 A2 ShineSing。当前是**已实现并测试的 FPGA 处理核心 + 硬件适配待接入**，
不是可直接下载到小车的完整工程。详细本轮状态见 `docs/ROUND1_PROGRESS_ZH.md`。

已经实现：实时灰度像素流的三行线检测、迭代质心计算、帧特征跨时钟传输、基础/二次曲线
前视跟踪、锁存急停、距离有效性/障碍停车、失线与图像超时停车、连续帧恢复、轮速饱和。
独立实现通用 UART 发射器和按键值索引的路口选择记忆。路口识别、移动绕障、VO 尚未实现。

`tb/mock_motor_packet.sv` 是**仅供仿真的协议**，不能接 Nano/UGV02。
官方摄像头配置、机器人接线、IR 键码、距离适配和底盘串口协议未在本地资料中找到。
`quartus/` 用虚拟数据引脚评估核心资源；没有机器人板级引脚映射，也没有可用 `.sof`。

## 从哪里读

- `docs/ROUND1_PROGRESS_ZH.md`：本轮系统结构、完成程度、测试结果与下一步。
- `docs/ARCHITECTURE.md`：模块图、时钟、宽度、控制优先级与计算公式。
- `docs/INTERFACES.md`：各模块真实接口及后续接板约定。
- `docs/HARDWARE_BLOCKERS.md`：所缺资料、实车接入顺序、串口急停问题。
- `docs/REQUIREMENTS_MATRIX.md`：R1–R9 已有证据与缺口。
- `docs/VALIDATION_PLAN.md`：自动测试范围、目标定义与真实数据回放格式。
- `OWNERS.md`：按 Pitch 保留的拟归属、共享模块待定项与代码来源。
- `docs/evidence/`：实际执行日志、结果 JSON 和 Quartus 结果。

## 标准自动测试

Linux / Ed 环境需要 Verilator **5.050**、C++ 编译器、make、Python 3（仅标准库）：

```bash
bash run_all_tests.sh
```

脚本检查版本，运行 full-size lint、模块/系统测试和一次性故障注入。
正常代码必须通过；故意把停车时左轮命令从 0 改成 1 的副本必须失败并输出 `CAUGHT`。
任何编译错误、超时或意外通过均返回非零。总执行预算 295 秒。

本机只有 Python 包提供的本地开发 Verilator 构建，不能冒充 5.050。Windows 复现命令：

```powershell
python tools/run_tests.py `
  --native-root 'E:\USYD\USYD_2-2\MTRX3700\ASSIGNMENT2\WORK\.deps\verilator' `
  --zig 'E:\USYD\USYD_2-2\MTRX3700\ASSIGNMENT2\WORK\.deps\ziglang\zig.exe' `
  --allow-version-mismatch
```

依赖路径只用于已有本机工具，不是项目源码依赖。换电脑用标准命令即可。
测试生成文件在 `build/`；无需安装 NumPy。最终提交前仍必须在指定版本从干净副本运行。

## 核心综合与资源估算

```bash
python3 tools/create_quartus.py
cd quartus
quartus_map robot_core --read_settings_files=on --write_settings_files=off
quartus_fit robot_core --read_settings_files=on --write_settings_files=off
quartus_sta robot_core
```

使用 Cyclone V `5CSEMA5F31C6`（沿用已核查的 V9 器件型号）。clk 假设 50 MHz，cam_clk
假设 24 MHz。数据引脚为虚拟引脚、两个时钟未指定板级位置；结果仅代表处理核心。
不要生成/下载这份估算工程的 bitstream；接板需官方配置和独立板级 wrapper。

## 真实回放

目前没有真实硬件录制。采集格式在 `data/README.md`。取得匹配的像素与 RTL 特征后：

```bash
python3 tools/compare_replay.py --pixels data/hardware/pixels.csv \
  --rtl data/hardware/rtl_features.csv --width 320 --height 240 --threshold 96
```

代码含本轮 AI 辅助生成内容。每位成员必须审核理解自己的模块及测试；组内尚未确认的
所有权不算 R8 完成。正式提交需附相关 AI 会话导出和 brief 要求的声明。
